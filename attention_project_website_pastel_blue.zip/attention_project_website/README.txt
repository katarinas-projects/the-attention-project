THE ATTENTION PROJECT WEBSITE

Files:
- index.html: the complete responsive website.

Preview:
Open index.html in a browser.

Publish with GitHub Pages:
1. Create or open a GitHub repository for the website.
2. Upload index.html to the top level of the repository.
3. Open Settings -> Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Choose the main branch and / (root), then Save.
6. Wait for GitHub to publish the site and open the URL shown in Settings -> Pages.

To edit:
Open index.html in GitHub and use the pencil icon, or edit it locally in a text editor.
The seven-day challenge progress is stored only in the visitor's own browser using localStorage.
The site uses Google Fonts and two Unsplash images, so those visual assets need an internet connection.
